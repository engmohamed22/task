package com.example.qurbatask.data

data class Reaction(
    val likeCount: Float,
    val commentCount: Int,
    val shareCount: Float
)
