package com.example.qurbatask.data

data class RestaurantInfo(
    val img: Int,
    val menuItem: String,
    val name: String
)
