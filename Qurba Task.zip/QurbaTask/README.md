QurbaTask
This is a recruitment task. The main requirment is using Jetpack Compose

<img src="/screenshots/pic1.png" width="360"/>
<img src="/screenshots/pic2.png" width="360"/>
<img src="/screenshots/pic3.png" width="360"/>